package com.doconnect.owner.util;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {
    private final Key key = Keys.hmacShaKeyFor("doconnectsecretkey1234567890abcdef".getBytes());
    private final long validity = 1000L * 60 * 60 * 24;

    public String generateToken(String username, Long ownerId) {
        return Jwts.builder()
                .setSubject(username)
                .claim("ownerId", ownerId)
                .claim("role", "OWNER")
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + validity))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parserBuilder().setSigningKey(key).build()
                .parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
            return true;
        } catch (JwtException ex) {
            return false;
        }
    }
}
