package com.doconnect.owner.controller;

import com.doconnect.owner.entity.Owner;
import com.doconnect.owner.repository.OwnerRepository;
import com.doconnect.owner.util.JwtUtil;
import com.doconnect.owner.client.UserServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.*;

@Controller
public class OwnerPageController {

    @Autowired
    private OwnerRepository ownerRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private UserServiceClient userClient;

    // ============================================
    // HOME
    // ============================================
    @GetMapping("/")
    public String home() {
        return "redirect:/login";
    }

    // ============================================
    // LOGIN
    // ============================================
    @GetMapping("/login")
    public String loginPage(Model model) {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
            @RequestParam String password,
            HttpSession session, Model model) {
        Optional<Owner> optOwner = ownerRepository.findByUsername(username);

        if (optOwner.isEmpty() || !passwordEncoder.matches(password, optOwner.get().getPassword())) {
            model.addAttribute("error", "Invalid credentials");
            return "login";
        }

        Owner owner = optOwner.get();
        if (!owner.isEnabled()) {
            model.addAttribute("error", "Account disabled");
            return "login";
        }

        String token = jwtUtil.generateToken(owner.getUsername(), owner.getId());
        session.setAttribute("token", token);
        session.setAttribute("ownerId", owner.getId());
        session.setAttribute("username", owner.getUsername());
        session.setAttribute("email", owner.getEmail());

        return "redirect:/dashboard";
    }

    // ============================================
    // REGISTER
    // ============================================
    @GetMapping("/register")
    public String registerPage(Model model) {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username,
            @RequestParam String password,
            @RequestParam String email,
            Model model) {
        if (ownerRepository.existsByUsername(username)) {
            model.addAttribute("msg", "Username already exists");
            return "register";
        }
        if (ownerRepository.existsByEmail(email)) {
            model.addAttribute("msg", "Email already exists");
            return "register";
        }

        Owner owner = new Owner();
        owner.setUsername(username);
        owner.setPassword(passwordEncoder.encode(password));
        owner.setEmail(email);
        ownerRepository.save(owner);

        model.addAttribute("msg", "Registration successful! Please login.");
        return "register";
    }

    // ============================================
    // LOGOUT
    // ============================================
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // ============================================
    // DASHBOARD
    // ============================================
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (session.getAttribute("ownerId") == null)
            return "redirect:/login";

        try {
            List<Map<String, Object>> questions = userClient.getAllQuestions();
            List<Map<String, Object>> users = userClient.getAllUsers();

            long pending = questions.stream().filter(q -> "PENDING".equals(q.get("status"))).count();
            long approved = questions.stream().filter(q -> "APPROVED".equals(q.get("status"))).count();

            model.addAttribute("totalQuestions", questions.size());
            model.addAttribute("pendingQuestions", pending);
            model.addAttribute("approvedQuestions", approved);
            model.addAttribute("totalUsers", users.size());
            model.addAttribute("username", session.getAttribute("username"));
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load data");
        }

        return "dashboard";
    }

    // ============================================
    // MANAGE USERS
    // ============================================
    @GetMapping("/users")
    public String manageUsers(HttpSession session, Model model) {
        if (session.getAttribute("ownerId") == null)
            return "redirect:/login";

        try {
            model.addAttribute("users", userClient.getAllUsers());
        } catch (Exception e) {
            model.addAttribute("users", List.of());
        }
        return "users";
    }

    @PostMapping("/users/activate")
    public String activateUser(@RequestParam Long id) {
        userClient.activateUser(id);
        return "redirect:/users";
    }

    @PostMapping("/users/deactivate")
    public String deactivateUser(@RequestParam Long id) {
        userClient.deactivateUser(id);
        return "redirect:/users";
    }

    // ============================================
    // MANAGE QUESTIONS
    // ============================================
    @GetMapping("/questions")
    public String manageQuestions(HttpSession session, Model model) {
        if (session.getAttribute("ownerId") == null)
            return "redirect:/login";

        try {
            model.addAttribute("questions", userClient.getAllQuestions());
        } catch (Exception e) {
            model.addAttribute("questions", List.of());
        }
        return "questions";
    }

    @PostMapping("/questions/approve")
    public String approveQuestion(@RequestParam Long id) {
        userClient.approveQuestion(id);
        return "redirect:/questions";
    }

    @PostMapping("/questions/reject")
    public String rejectQuestion(@RequestParam Long id) {
        userClient.rejectQuestion(id);
        return "redirect:/questions";
    }

    @PostMapping("/questions/close")
    public String closeQuestion(@RequestParam Long id) {
        userClient.closeQuestion(id);
        return "redirect:/questions";
    }

    @PostMapping("/questions/delete")
    public String deleteQuestion(@RequestParam Long id) {
        userClient.deleteQuestion(id);
        return "redirect:/questions";
    }

    // ============================================
    // QUESTION DETAILS & ANSWERS
    // ============================================
    @GetMapping("/question/{id}")
    public String questionDetail(@PathVariable Long id, HttpSession session, Model model) {
        if (session.getAttribute("ownerId") == null)
            return "redirect:/login";

        try {
            model.addAttribute("question", userClient.getQuestion(id));
            model.addAttribute("answers", userClient.getAnswers(id));
        } catch (Exception e) {
            return "redirect:/questions";
        }
        return "questionDetail";
    }

    @PostMapping("/answers/approve")
    public String approveAnswer(@RequestParam Long id, @RequestParam Long questionId) {
        userClient.approveAnswer(id);
        return "redirect:/question/" + questionId;
    }

    @PostMapping("/answers/reject")
    public String rejectAnswer(@RequestParam Long id, @RequestParam Long questionId) {
        userClient.rejectAnswer(id);
        return "redirect:/question/" + questionId;
    }

    @PostMapping("/answers/delete")
    public String deleteAnswer(@RequestParam Long id, @RequestParam Long questionId) {
        userClient.deleteAnswer(id);
        return "redirect:/question/" + questionId;
    }
}
