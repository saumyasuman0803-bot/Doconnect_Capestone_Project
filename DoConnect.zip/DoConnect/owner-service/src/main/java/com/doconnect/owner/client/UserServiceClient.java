package com.doconnect.owner.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@FeignClient(name = "USER-SERVICE")
public interface UserServiceClient {

    @GetMapping("/api/users")
    List<Map<String, Object>> getAllUsers();

    @GetMapping("/api/users/{id}")
    Map<String, Object> getUserById(@PathVariable Long id);

    @PutMapping("/api/users/{id}/activate")
    void activateUser(@PathVariable Long id);

    @PutMapping("/api/users/{id}/deactivate")
    void deactivateUser(@PathVariable Long id);

    @GetMapping("/api/questions/all")
    List<Map<String, Object>> getAllQuestions();

    @GetMapping("/api/questions/{id}")
    Map<String, Object> getQuestion(@PathVariable Long id);

    @PutMapping("/api/questions/{id}/approve")
    void approveQuestion(@PathVariable Long id);

    @PutMapping("/api/questions/{id}/reject")
    void rejectQuestion(@PathVariable Long id);

    @PutMapping("/api/questions/{id}/close")
    void closeQuestion(@PathVariable Long id);

    @DeleteMapping("/api/questions/{id}")
    void deleteQuestion(@PathVariable Long id);

    @GetMapping("/api/answers/question/{questionId}/all")
    List<Map<String, Object>> getAnswers(@PathVariable Long questionId);

    @PutMapping("/api/answers/{id}/approve")
    void approveAnswer(@PathVariable Long id);

    @PutMapping("/api/answers/{id}/reject")
    void rejectAnswer(@PathVariable Long id);

    @DeleteMapping("/api/answers/{id}")
    void deleteAnswer(@PathVariable Long id);
}
