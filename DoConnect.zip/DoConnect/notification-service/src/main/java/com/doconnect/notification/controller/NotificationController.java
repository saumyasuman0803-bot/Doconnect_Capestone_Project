package com.doconnect.notification.controller;

import com.doconnect.notification.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notify")
public class NotificationController {

    @Autowired
    private EmailService emailService;

    // -------------------------------------------------------
    // NOTIFY NEW QUESTION
    // -------------------------------------------------------
    @PostMapping("/question")
    public ResponseEntity<String> notifyNewQuestion(@RequestBody Map<String, Object> request) {
        Long questionId = Long.valueOf(request.get("questionId").toString());
        String title = (String) request.get("title");

        emailService.sendNewQuestionNotification(questionId, title);

        return ResponseEntity.ok("Notification sent for new question #" + questionId);
    }

    // -------------------------------------------------------
    // NOTIFY NEW ANSWER
    // -------------------------------------------------------
    @PostMapping("/answer")
    public ResponseEntity<String> notifyNewAnswer(@RequestBody Map<String, Object> request) {
        Long answerId = Long.valueOf(request.get("answerId").toString());
        Long questionId = Long.valueOf(request.get("questionId").toString());

        emailService.sendNewAnswerNotification(answerId, questionId);

        return ResponseEntity.ok("Notification sent for new answer #" + answerId);
    }

    // -------------------------------------------------------
    // HEALTH CHECK
    // -------------------------------------------------------
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Notification Service is running");
    }
}
