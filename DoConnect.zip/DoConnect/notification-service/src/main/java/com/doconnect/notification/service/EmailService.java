package com.doconnect.notification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${admin.notification.email}")
    private String adminEmail;

    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendNewQuestionNotification(Long questionId, String title) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(adminEmail);
            message.setSubject("DoConnect: New Question Posted - ID #" + questionId);
            message.setText("A new question has been posted on DoConnect.\n\n" +
                    "Question ID: " + questionId + "\n" +
                    "Title: " + title + "\n\n" +
                    "Please login to the admin portal to approve or reject this question.\n\n" +
                    "Admin Portal: http://localhost:8082");

            mailSender.send(message);
            System.out.println("Email sent: New question notification for ID #" + questionId);
        } catch (Exception e) {
            System.err.println("Failed to send email: " + e.getMessage());
        }
    }

    public void sendNewAnswerNotification(Long answerId, Long questionId) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(adminEmail);
            message.setSubject("DoConnect: New Answer Posted - Question #" + questionId);
            message.setText("A new answer has been posted on DoConnect.\n\n" +
                    "Answer ID: " + answerId + "\n" +
                    "Question ID: " + questionId + "\n\n" +
                    "Please login to the admin portal to approve or reject this answer.\n\n" +
                    "Admin Portal: http://localhost:8082");

            mailSender.send(message);
            System.out.println("Email sent: New answer notification for Answer #" + answerId);
        } catch (Exception e) {
            System.err.println("Failed to send email: " + e.getMessage());
        }
    }
}
