package com.doconnect.user.controller;

import com.doconnect.user.entity.Answer;
import com.doconnect.user.repository.AnswerRepository;
import com.doconnect.user.client.NotificationClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/answers")
public class AnswerController {

    @Autowired
    private AnswerRepository answerRepository;

    @Autowired(required = false)
    private NotificationClient notificationClient;

    // -------------------------------------------------------
    // GET ANSWERS FOR QUESTION (approved only for users)
    // -------------------------------------------------------
    @GetMapping("/question/{questionId}")
    public List<Answer> getByQuestion(@PathVariable Long questionId) {
        return answerRepository.findByQuestionIdAndApprovedTrue(questionId);
    }

    // -------------------------------------------------------
    // GET ALL ANSWERS FOR QUESTION (for owner)
    // -------------------------------------------------------
    @GetMapping("/question/{questionId}/all")
    public List<Answer> getAllByQuestion(@PathVariable Long questionId) {
        return answerRepository.findByQuestionId(questionId);
    }

    // -------------------------------------------------------
    // POST ANSWER
    // -------------------------------------------------------
    @PostMapping
    public ResponseEntity<?> postAnswer(@RequestBody Map<String, Object> req) {
        Answer a = new Answer();
        a.setQuestionId(Long.valueOf(req.get("questionId").toString()));
        a.setAnswerText((String) req.get("answerText"));
        a.setAnsweredBy(Long.valueOf(req.get("answeredBy").toString()));
        a.setApproved(false); // Needs admin approval

        Answer saved = answerRepository.save(a);

        // Notify about new answer
        try {
            if (notificationClient != null) {
                notificationClient.notifyNewAnswer(Map.of(
                        "answerId", saved.getId(),
                        "questionId", saved.getQuestionId()));
            }
        } catch (Exception e) {
            // Log but don't fail
        }

        return ResponseEntity.ok(saved);
    }

    // -------------------------------------------------------
    // LIKE ANSWER
    // -------------------------------------------------------
    @PutMapping("/{id}/like")
    public ResponseEntity<String> like(@PathVariable Long id) {
        return answerRepository.findById(id)
                .map(a -> {
                    a.setLikes(a.getLikes() + 1);
                    answerRepository.save(a);
                    return ResponseEntity.ok("Liked");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // APPROVE ANSWER (for owner)
    // -------------------------------------------------------
    @PutMapping("/{id}/approve")
    public ResponseEntity<String> approve(@PathVariable Long id) {
        return answerRepository.findById(id)
                .map(a -> {
                    a.setApproved(true);
                    answerRepository.save(a);
                    return ResponseEntity.ok("Answer approved");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // REJECT ANSWER (for owner)
    // -------------------------------------------------------
    @PutMapping("/{id}/reject")
    public ResponseEntity<String> reject(@PathVariable Long id) {
        return answerRepository.findById(id)
                .map(a -> {
                    a.setApproved(false);
                    answerRepository.save(a);
                    return ResponseEntity.ok("Answer rejected");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // DELETE ANSWER (for owner)
    // -------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        if (answerRepository.existsById(id)) {
            answerRepository.deleteById(id);
            return ResponseEntity.ok("Answer deleted");
        }
        return ResponseEntity.notFound().build();
    }
}
