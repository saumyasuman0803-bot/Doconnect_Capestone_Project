package com.doconnect.user.controller;

import com.doconnect.user.entity.User;
import com.doconnect.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // -------------------------------------------------------
    // GET ALL USERS
    // -------------------------------------------------------
    @GetMapping
    public List<User> getAll() {
        return userRepository.findAll();
    }

    // -------------------------------------------------------
    // GET USER BY ID
    // -------------------------------------------------------
    @GetMapping("/{id}")
    public ResponseEntity<User> getById(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // GET USER BY USERNAME
    // -------------------------------------------------------
    @GetMapping("/username/{username}")
    public ResponseEntity<User> getByUsername(@PathVariable String username) {
        return userRepository.findByUsername(username)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // ACTIVATE USER (for owner)
    // -------------------------------------------------------
    @PutMapping("/{id}/activate")
    public ResponseEntity<String> activate(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(u -> {
                    u.setEnabled(true);
                    userRepository.save(u);
                    return ResponseEntity.ok("User activated");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // DEACTIVATE USER (for owner)
    // -------------------------------------------------------
    @PutMapping("/{id}/deactivate")
    public ResponseEntity<String> deactivate(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(u -> {
                    u.setEnabled(false);
                    userRepository.save(u);
                    return ResponseEntity.ok("User deactivated");
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
