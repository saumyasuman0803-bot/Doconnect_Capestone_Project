package com.doconnect.user.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;

@FeignClient(name = "NOTIFICATION-SERVICE")
public interface NotificationClient {

    @PostMapping("/api/notify/question")
    void notifyNewQuestion(@RequestBody Map<String, Object> request);

    @PostMapping("/api/notify/answer")
    void notifyNewAnswer(@RequestBody Map<String, Object> request);
}
