package com.doconnect.user.controller;

import com.doconnect.user.entity.Question;
import com.doconnect.user.repository.QuestionRepository;
import com.doconnect.user.client.NotificationClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/questions")
public class QuestionController {

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired(required = false)
    private NotificationClient notificationClient;

    // -------------------------------------------------------
    // GET ALL APPROVED QUESTIONS
    // -------------------------------------------------------
    @GetMapping
    public List<Question> getAllApproved() {
        return questionRepository.findByStatusAndActiveTrueOrderByCreatedAtDesc("APPROVED");
    }

    // -------------------------------------------------------
    // GET ALL QUESTIONS (for owner service)
    // -------------------------------------------------------
    @GetMapping("/all")
    public List<Question> getAll() {
        return questionRepository.findAll();
    }

    // -------------------------------------------------------
    // SEARCH QUESTIONS
    // -------------------------------------------------------
    @GetMapping("/search")
    public List<Question> search(@RequestParam String q) {
        return questionRepository.searchApproved(q);
    }

    // -------------------------------------------------------
    // GET QUESTION BY ID
    // -------------------------------------------------------
    @GetMapping("/{id}")
    public ResponseEntity<Question> getById(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // GET QUESTIONS BY USER
    // -------------------------------------------------------
    @GetMapping("/user/{userId}")
    public List<Question> getByUser(@PathVariable Long userId) {
        return questionRepository.findByAskedBy(userId);
    }

    // -------------------------------------------------------
    // ASK QUESTION (CREATE)
    // -------------------------------------------------------
    @PostMapping
    public ResponseEntity<?> askQuestion(@RequestBody Map<String, Object> req) {
        Question q = new Question();
        q.setTitle((String) req.get("title"));
        q.setDescription((String) req.get("description"));
        q.setAskedBy(Long.valueOf(req.get("askedBy").toString()));
        q.setStatus("PENDING");

        Question saved = questionRepository.save(q);

        // Notify owner service about new question
        try {
            if (notificationClient != null) {
                notificationClient.notifyNewQuestion(Map.of(
                        "questionId", saved.getId(),
                        "title", saved.getTitle()));
            }
        } catch (Exception e) {
            // Log but don't fail
        }

        return ResponseEntity.ok(saved);
    }

    // -------------------------------------------------------
    // APPROVE QUESTION (for owner service)
    // -------------------------------------------------------
    @PutMapping("/{id}/approve")
    public ResponseEntity<String> approve(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(q -> {
                    q.setStatus("APPROVED");
                    questionRepository.save(q);
                    return ResponseEntity.ok("Question approved");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // REJECT QUESTION (for owner service)
    // -------------------------------------------------------
    @PutMapping("/{id}/reject")
    public ResponseEntity<String> reject(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(q -> {
                    q.setStatus("REJECTED");
                    questionRepository.save(q);
                    return ResponseEntity.ok("Question rejected");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // CLOSE QUESTION (for owner service)
    // -------------------------------------------------------
    @PutMapping("/{id}/close")
    public ResponseEntity<String> close(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(q -> {
                    q.setClosed(true);
                    questionRepository.save(q);
                    return ResponseEntity.ok("Question closed");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // DEACTIVATE QUESTION (for owner service)
    // -------------------------------------------------------
    @PutMapping("/{id}/deactivate")
    public ResponseEntity<String> deactivate(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(q -> {
                    q.setActive(false);
                    questionRepository.save(q);
                    return ResponseEntity.ok("Question deactivated");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // -------------------------------------------------------
    // DELETE QUESTION (for owner service)
    // -------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        if (questionRepository.existsById(id)) {
            questionRepository.deleteById(id);
            return ResponseEntity.ok("Question deleted");
        }
        return ResponseEntity.notFound().build();
    }
}
