package com.doconnect.user.controller;

import com.doconnect.user.entity.ChatMessage;
import com.doconnect.user.repository.ChatMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    @Autowired
    private ChatMessageRepository chatRepository;

    // -------------------------------------------------------
    // SEND MESSAGE
    // -------------------------------------------------------
    @PostMapping("/send")
    public ResponseEntity<?> send(@RequestBody Map<String, Object> req) {
        Long senderId = Long.valueOf(req.get("senderId").toString());
        Long receiverId = Long.valueOf(req.get("receiverId").toString());
        String message = (String) req.get("message");

        ChatMessage chat = new ChatMessage(senderId, receiverId, message);
        ChatMessage saved = chatRepository.save(chat);

        return ResponseEntity.ok(Map.of(
                "status", "sent",
                "chatId", saved.getId(),
                "timestamp", saved.getTimestamp().toString()));
    }

    // -------------------------------------------------------
    // GET CHAT HISTORY BETWEEN TWO USERS
    // -------------------------------------------------------
    @GetMapping("/history")
    public List<ChatMessage> getHistory(@RequestParam Long user1, @RequestParam Long user2) {
        List<ChatMessage> sent = chatRepository.findBySenderIdAndReceiverIdOrderByTimestamp(user1, user2);
        List<ChatMessage> received = chatRepository.findBySenderIdAndReceiverIdOrderByTimestamp(user2, user1);

        List<ChatMessage> all = new ArrayList<>();
        all.addAll(sent);
        all.addAll(received);
        all.sort(Comparator.comparing(ChatMessage::getTimestamp));

        return all;
    }

    // -------------------------------------------------------
    // GET ALL MESSAGES FOR USER
    // -------------------------------------------------------
    @GetMapping("/user/{userId}")
    public List<ChatMessage> getUserMessages(@PathVariable Long userId) {
        return chatRepository.findBySenderIdOrReceiverIdOrderByTimestamp(userId, userId);
    }
}
