package com.doconnect.user.controller;

import com.doconnect.user.entity.*;
import com.doconnect.user.repository.*;
import com.doconnect.user.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.*;

@Controller
public class PageController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private QuestionRepository questionRepository;
    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private ChatMessageRepository chatRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;

    // ============================================
    // HOME
    // ============================================
    @GetMapping("/")
    public String home() {
        return "redirect:/login";
    }

    // ============================================
    // LOGIN PAGE
    // ============================================
    @GetMapping("/login")
    public String loginPage(Model model) {
        model.addAttribute("error", null);
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
            @RequestParam String password,
            HttpSession session, Model model) {
        Optional<User> optUser = userRepository.findByUsername(username);

        if (optUser.isEmpty() || !passwordEncoder.matches(password, optUser.get().getPassword())) {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }

        User user = optUser.get();
        if (!user.isEnabled()) {
            model.addAttribute("error", "Your account is disabled");
            return "login";
        }

        String token = jwtUtil.generateToken(user.getUsername(), user.getId());
        session.setAttribute("token", token);
        session.setAttribute("userId", user.getId());
        session.setAttribute("username", user.getUsername());

        return "redirect:/dashboard";
    }

    // ============================================
    // REGISTER PAGE
    // ============================================
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("msg", null);
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username,
            @RequestParam String password,
            @RequestParam String email,
            Model model) {
        if (userRepository.existsByUsername(username)) {
            model.addAttribute("msg", "Username already exists");
            return "register";
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setEmail(email);
        userRepository.save(user);

        model.addAttribute("msg", "Registration successful! Please login.");
        return "register";
    }

    // ============================================
    // LOGOUT
    // ============================================
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // ============================================
    // DASHBOARD
    // ============================================
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("myQuestions", questionRepository.findByAskedBy(userId).size());
        model.addAttribute("myAnswers", answerRepository.findByAnsweredBy(userId).size());

        return "dashboard";
    }

    // ============================================
    // QUESTIONS LIST
    // ============================================
    @GetMapping("/questions")
    public String questions(@RequestParam(required = false) String q,
            HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        List<Question> questions;
        if (q != null && !q.isEmpty()) {
            questions = questionRepository.searchApproved(q);
            model.addAttribute("searchQuery", q);
        } else {
            questions = questionRepository.findByStatusAndActiveTrueOrderByCreatedAtDesc("APPROVED");
        }

        model.addAttribute("questions", questions);
        return "questions";
    }

    // ============================================
    // ASK QUESTION
    // ============================================
    @GetMapping("/ask")
    public String askPage(HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";
        return "ask";
    }

    @PostMapping("/ask")
    public String ask(@RequestParam String title,
            @RequestParam String description,
            HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");

        Question q = new Question();
        q.setTitle(title);
        q.setDescription(description);
        q.setAskedBy(userId);
        q.setStatus("PENDING");
        questionRepository.save(q);

        model.addAttribute("msg", "Question submitted! Waiting for admin approval.");
        return "ask";
    }

    // ============================================
    // QUESTION DETAILS
    // ============================================
    @GetMapping("/question/{id}")
    public String questionDetail(@PathVariable Long id, HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Optional<Question> optQ = questionRepository.findById(id);
        if (optQ.isEmpty())
            return "redirect:/questions";

        Question question = optQ.get();
        List<Answer> answers = answerRepository.findByQuestionIdAndApprovedTrue(id);

        // Load comments for each answer
        Map<Long, List<Comment>> answerComments = new HashMap<>();
        for (Answer a : answers) {
            answerComments.put(a.getId(), commentRepository.findByAnswerId(a.getId()));
        }

        model.addAttribute("question", question);
        model.addAttribute("answers", answers);
        model.addAttribute("answerComments", answerComments);
        model.addAttribute("userId", session.getAttribute("userId"));

        return "questionDetail";
    }

    // ============================================
    // POST ANSWER
    // ============================================
    @PostMapping("/answer")
    public String postAnswer(@RequestParam Long questionId,
            @RequestParam String answerText,
            HttpSession session) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");

        Answer a = new Answer();
        a.setQuestionId(questionId);
        a.setAnswerText(answerText);
        a.setAnsweredBy(userId);
        a.setApproved(false);
        answerRepository.save(a);

        return "redirect:/question/" + questionId;
    }

    // ============================================
    // LIKE ANSWER
    // ============================================
    @PostMapping("/like")
    public String likeAnswer(@RequestParam Long answerId, @RequestParam Long questionId) {
        answerRepository.findById(answerId).ifPresent(a -> {
            a.setLikes(a.getLikes() + 1);
            answerRepository.save(a);
        });
        return "redirect:/question/" + questionId;
    }

    // ============================================
    // POST COMMENT
    // ============================================
    @PostMapping("/comment")
    public String postComment(@RequestParam Long answerId,
            @RequestParam Long questionId,
            @RequestParam String commentText,
            HttpSession session) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");

        Comment c = new Comment();
        c.setAnswerId(answerId);
        c.setCommentText(commentText);
        c.setCommentedBy(userId);
        commentRepository.save(c);

        return "redirect:/question/" + questionId;
    }

    // ============================================
    // CHAT
    // ============================================
    @GetMapping("/chat")
    public String chat(@RequestParam(required = false) Long receiverId,
            HttpSession session, Model model) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");
        List<User> users = userRepository.findAll();

        model.addAttribute("users", users);
        model.addAttribute("senderId", userId);
        model.addAttribute("receiverId", receiverId != null ? receiverId : 0L);

        if (receiverId != null) {
            List<ChatMessage> sent = chatRepository.findBySenderIdAndReceiverIdOrderByTimestamp(userId, receiverId);
            List<ChatMessage> received = chatRepository.findBySenderIdAndReceiverIdOrderByTimestamp(receiverId, userId);
            List<ChatMessage> all = new ArrayList<>();
            all.addAll(sent);
            all.addAll(received);
            all.sort(Comparator.comparing(ChatMessage::getTimestamp));
            model.addAttribute("messages", all);
        } else {
            model.addAttribute("messages", List.of());
        }

        return "chat";
    }

    @PostMapping("/chat/send")
    public String sendChat(@RequestParam Long receiverId,
            @RequestParam String message,
            HttpSession session) {
        if (session.getAttribute("userId") == null)
            return "redirect:/login";

        Long userId = (Long) session.getAttribute("userId");

        ChatMessage chat = new ChatMessage(userId, receiverId, message);
        chatRepository.save(chat);

        return "redirect:/chat?receiverId=" + receiverId;
    }
}
