package com.doconnect.user.repository;

import com.doconnect.user.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByStatus(String status);

    List<Question> findByAskedBy(Long userId);

    List<Question> findByStatusAndActiveTrue(String status);

    @Query("SELECT q FROM Question q WHERE q.status = 'APPROVED' AND q.active = true AND (LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(q.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Question> searchApproved(String keyword);

    List<Question> findByStatusAndActiveTrueOrderByCreatedAtDesc(String status);
}
