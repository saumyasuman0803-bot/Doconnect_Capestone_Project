package com.doconnect.user.controller;

import com.doconnect.user.entity.Comment;
import com.doconnect.user.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    @Autowired
    private CommentRepository commentRepository;

    // -------------------------------------------------------
    // GET COMMENTS FOR ANSWER
    // -------------------------------------------------------
    @GetMapping("/answer/{answerId}")
    public List<Comment> getByAnswer(@PathVariable Long answerId) {
        return commentRepository.findByAnswerId(answerId);
    }

    // -------------------------------------------------------
    // POST COMMENT
    // -------------------------------------------------------
    @PostMapping
    public ResponseEntity<?> postComment(@RequestBody Map<String, Object> req) {
        Comment c = new Comment();
        c.setAnswerId(Long.valueOf(req.get("answerId").toString()));
        c.setCommentText((String) req.get("commentText"));
        c.setCommentedBy(Long.valueOf(req.get("commentedBy").toString()));

        Comment saved = commentRepository.save(c);
        return ResponseEntity.ok(saved);
    }

    // -------------------------------------------------------
    // DELETE COMMENT
    // -------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        if (commentRepository.existsById(id)) {
            commentRepository.deleteById(id);
            return ResponseEntity.ok("Comment deleted");
        }
        return ResponseEntity.notFound().build();
    }
}
