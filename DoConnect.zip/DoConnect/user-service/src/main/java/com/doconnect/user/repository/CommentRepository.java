package com.doconnect.user.repository;

import com.doconnect.user.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByAnswerId(Long answerId);

    List<Comment> findByCommentedBy(Long userId);
}
